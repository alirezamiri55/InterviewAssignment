I have completed all parts and symmetric placement of numbers.

The only problem with this code is that, making hard or samurai sudoku might take long time. Because, the sudoku generator is not able to predict the difficulty of the sudoku, while is making that. This code checks that the difficulty of generated sudoku is what we want or not, then it start over if it is not the desired difficulty.

This code were developed and tested on the Linux with g++ compiler.
This code need at least C++14 to compile.
